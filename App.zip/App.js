import React, { Component } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import CameraExample from './screens/CameraExample'
import PictureShow from './screens/PictureShow'

import { createStackNavigator, createAppContainer } from "react-navigation";

class App extends Component {
  render() {
    return (
      <View style={{flex: 1}}>
          <CameraExample />
          
      </View>
    );
  }
}

const AppNavigator = createStackNavigator({
  Home: {
    screen: App
  }
});


export default createAppContainer(AppNavigator);